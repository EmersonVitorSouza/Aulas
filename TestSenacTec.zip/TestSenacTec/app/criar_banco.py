from app.database import criar_banco

criar_banco()
