# Importa o modelo (UserModel e a classe User)
from model.user_model import UserModel, User
# Importa a interface gráfica
from view.user_view import UserView

# Classe que faz a ponte entre View e Model
class UserController:
    def __init__(self):
        self.model = UserModel()     # Cria a instância do modelo
        self.view = UserView(self)   # Cria a view e passa a si mesmo (controller)

    def run(self):
        self.view.start()  # Inicia o loop da interface gráfica

    def add_user(self, name, email):
        user = User(name, email)       # Cria um novo usuário
        self.model.add_user(user)      # Adiciona o usuário via model

    def get_users(self):
        return self.model.get_all_users()  # Busca usuários via model
